import React from 'react';

function Separator() {
  return <div className="my-4 border-black border-t opacity-20" />;
}

export default Separator;

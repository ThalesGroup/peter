export enum Category {
  NONE = 'NO_CATEGORY',
  X = 'X',
  E = 'E',
  M = 'M',
  EM = 'EM',
}

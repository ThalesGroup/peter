export enum RecyclingType {
  NONE = 'NONE',
  TYPE_1 = 'TYPE_1',
  TYPE_2 = 'TYPE_2',
}

export type PowerLevelId = string;
export interface PowerLevel {
  id: PowerLevelId;
  power: number;
  share: number;
}

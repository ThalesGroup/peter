export enum InUseMobilityType {
  NONE = 'NONE',
  EMBEDDED = 'EMBEDDED',
  TRANSPORTED = 'TRANSPORTED',
}

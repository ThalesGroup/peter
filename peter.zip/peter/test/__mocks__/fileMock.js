module.exports = 'http://test-file-stub';
